This folder contains pre-trained model for human NA12878 Bham Run1 cDNA dataset.

Source
https://s3.amazonaws.com/nanopore-human-wgs/rna/fastq/Bham_Run1_20171120_1D2_1Donly.all.dedeup.fastq

Data type
cDNA 1D2

Kit
SQK-LSK308

Pore
R9.4

Basecaller
Albacore 2.1
