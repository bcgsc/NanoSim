This folder contains pre-trained model for mouse C57Bl/6 cDNA dataset.

Source
https://www.ncbi.nlm.nih.gov/sra/?term=SRR5286960

Data type
cDNA single-cell

Pore
R9.4

Basecaller
Metrichor
