This folder contains pre-trained model for human NA12878 Bham DNA dataset.

Source
http://s3.amazonaws.com/nanopore-human-wgs/rel6/MultiFast5Tars/FAB49712-622291475_Multi_Fast5.tar

Data type
DNA

Kit
Ligation

Pore
R9.4

Basecaller
Albacore 2.3.1
