This folder contains pre-trained model for human NA12878 Bham Run1 direct DNA dataset.

Source
http://s3.amazonaws.com/nanopore-human-wgs/rna/links/Bham_Run1_20171009_DirectRNA.files.txt

Data type
direct RNA

Kit
SQK-RNA001

Pore
R9.4

Basecaller
Guppy 3.1.5
